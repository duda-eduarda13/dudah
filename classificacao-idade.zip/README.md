# Projeto: Classificação por Idade

Este projeto classifica uma pessoa como criança, adolescente ou adulta com base na idade informada.

## Como usar este projeto no GitHub Pages

### Passo a passo:

1. Acesse [https://github.com](https://github.com) e faça login.

2. Crie um novo repositório com o nome `classificacao-idade` (pode ser outro nome também).

3. NÃO selecione a opção "Add README".

4. Após criado, clique na opção **Add file > Upload files**.

5. Faça upload do arquivo `index.html` deste projeto.

6. Clique em **Commit changes** no final da página.

7. Vá em **Settings > Pages** no menu lateral.

8. Em **Source**, selecione `Deploy from a branch`, `main` e pasta `/root`, depois clique em **Save**.

9. Espere alguns segundos e o link do seu site será gerado.

Pronto! Você criou uma página com classificação por idade usando GitHub Pages.
